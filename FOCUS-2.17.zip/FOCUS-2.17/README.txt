				README

============
Requirements
============
IBM FOCUS is implemented in Pure Java, so it can run on any platform that
has a Java virtual machine, with JRE (Java Run-time Environment) version 7 (1.7) or above. 
A JRE is installed by default on almost all environments. 
If you write restrictions in advanced Java syntax, you will be prompted to install a JDK 
(version 7 or above) rather than a JRE, since in this case a JRE will not suffice. 
For IBM employees, JDK 7 or above should be downloaded from Hursley
(http://w3.hursley.ibm.com/java/jim).

IBM internal users need to authenticate to the intranet when invoking IBM FOCUS.
For convenience, the intranet password can be provided to IBM FOCUS also via the JVM
argument 'focus.password'.

============
Installation
============

1. Extract the distribution package focus.zip into a directory.

2. Run the "focus.bat" script (Windows) or "focus" (unix). The scripts invoke
 the command "java". 
 
 Instructions for Mac users:
 ----------------------------------
 
 1. Unzip the focus.zip package by opening a terminal, running the command 'cd' to 
 navigate to the parent folder on the zip file, and then running the command 'unzip focus.zip'.
 
 For example, if your focus.zip file is called FOCUS-2.5.zip and is located in /Users/myuser/Downloads/, 
 type the following two commands:
 
 cd /Users/myuser/Downloads
 unzip FOCUS-2.5.zip
 
 NOTE: DO NOT extract the zip file via the archive utility or by double-clicking the zipped folder, 
 since this will create an erroneous unzipped folder. 
 
 2. From the terminal command line, run the command:
 cd <path to FOCUS unzipped folder>. 
 	For example: cd /Users/myuser/Downloads/FOCUS-2.5
 	You can make sure that you reached the right location that includes the focus script file 
 	by running the command 'ls', and making sure you see the focus script in the list of files and folders.
 3. To invoke the FOCUS tool, from the terminal command line run the command:
 ./focus 
 
 If the command is not found, you will need to change the focus script file permission by adding execute permissions, 
 and then rerun the script:
 
 chmod "+x" focus
 ./focus 
 
 
 Special note for Windows 7 users:
 ----------------------------------
 
 If you are running IBM FOCUS on Windows 7 and getting "'Java' is not recognized as an internal or external command",
 this is the result of a problem in your default Java installation, 
 that does not include its path in the windows path. To resolve it, perform the following steps:

    Go to Start -> Control Panel -> System
    Click on the 'Advanced System Settings' link on the left
    Click the 'Environment Variables' button
    In the lower section (Labeled 'System Variables'), scroll through and find the item labeled 'Path' and double click it
    In the field labeled 'Variable value' go to the end and add a semicolon (;), and then the path your installation of Java is located - for example, ";C:\Program Files (x86)\Java\jre6\bin"

    If the above doesn't work for you, you can also edit the focus.bat file and replace the 'java' 
    at the beginning with its full path (e.g., "C:\Program Files (x86)\Java\jre6\bin\java"). 
    However, you will have to repeat this whenever you update to a new version of IBM FOCUS, 
    so it is better to correctly define the windows path to include the default Java path. 
 
3. A configuration utility is also supplied with the IBM FOCUS package. To start
   it, run "config.bat" (Windows) or "config" (unix). The utility may be used
   for configuring the following:
   a. The character set to be used by IBM FOCUS. If you require to use non-English 
      characters in your models, you must make sure the character set complies
      with your language. Note that English characters are always allowed, and
      the chosen character set affects the characters that may be used in 
      addition to English.
   b. The path to your JDK java executable, in case you need one.
   
   After invoking the configuration utility, choose your character set and path 
   to the JDK java executable, and click Apply. This will modify your focus  
   execution scripts accordingly, such that in all future invocations of IBM FOCUS, 
   these settings will be used.
   Note that using the configuration is not always required, and may be skipped
   if you're using only Latin characters and you do not need a JDK, or you do need 
   a JDK but your default Java is already a JDK one. 

========
Tutorial
========

The online tutorial is in focusTutorial/tutorial.html


Have fun using IBM FOCUS!


	
