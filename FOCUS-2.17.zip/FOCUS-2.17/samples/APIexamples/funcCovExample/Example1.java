/*****************************************************************************/
/*        (c) IBM corporation (1997, 2007), ALL RIGHTS RESERVED              */
/*****************************************************************************/

import com.ibm.focus.*;
import java.io.*;

/** This program gets a model file name and one or more trace file names. It computes legal coverage
report, outputs the coverage percentage, and writes the report to a CSV file. Then it computes
coverage holes report with the same coverage data, and says the size of the biggest coverage hole.
<p>
Usage: see method usage(), or execute the program without arguments.
<p>
The output file name is specified in command line. If a file with that name existed, it is
overwritten.
<p>
not verbose: does not print anything unless there is fatal error. */
public class Example1 {
   public static void main(String[] args) throws Exception{
      if (args.length < 3) {
         usage();
         return;
      }
      File modelFile = new File(args[0]);
      File reportFile = new File(args[1]);
      ReportGenerator rg = new ReportGenerator(modelFile);

      //add traces: simply all the files denoted by the third argument and all later arguments.
      for (int i = args.length - 1; i >=2; i--) {
         String curTraceName = args[i];
         File curTraceFile = new File(curTraceName);
         rg.addTrace(curTraceFile);
      }
      RegularCoverageReport rcr = rg.getRegularCoverageReport(true,
            RegularCoverageReport.NO_COUNT_LIMIT, RegularCoverageReport.NO_COUNT_LIMIT);

      System.out.println("total coverage percentage is: " + rcr.getCoveragePercentage());

      //prints the report to file
      BufferedWriter writer = new BufferedWriter(new FileWriter(reportFile));
      rcr.printCSV(writer, false);

      SubsetHoles.SubsetHolesSolution hr = rg.getSubsetHoles(10, 0f);      
      for (int i=1; i<=hr.goodPathSolution.getMaximalHoleSize(); i++) {
         if ( ! hr.goodPathSolution.getHolesOfSize(i).isEmpty()) {
            System.out.println("the biggest coverage holes are of size: " + i);
            return;
         }
      }
      System.out.println("No holes found.");
   }

   public static void usage() {
      System.out.println(
         "Usage: java -classpath ... Example1 modelFileName outputFileName traceFileName1 [traceFileName2] [traceFileName3] ...");
      System.out.println();
      System.out.println("You can use wildcards when specifying traces (e.g. traceFir\\*.trace)");
   }
}



