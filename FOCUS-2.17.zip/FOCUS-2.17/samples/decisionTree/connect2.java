assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("no")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("yes")) && (knob.equals("all")) && (located.equals("fail")) && (connected_to_failed_handle.equals("no")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("yes")) && (knob.equals("not_applicable")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("yes")) && (knob.equals("all")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("yes")) && (knob.equals("fail")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("yes")) && (knob.equals("not_applicable")) && (isKnob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("no")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("yes")) && (knob.equals("not_applicable")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (knob.equals("all")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (knob.equals("fail")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (knob.equals("not_applicable")) && (located.equals("all")) && (isKnob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (knob.equals("not_applicable")) && (located.equals("fail")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("yes")) && (knob.equals("all")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("yes")) && (knob.equals("fail")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (located.equals("all")) && (isHandle.equals("no")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (located.equals("all")) && (isHandle.equals("yes")) && (isKnob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) && (connected_to_failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (located.equals("fail")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("no")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("no")) && (isKnob.equals("yes")) && (knob.equals("not_applicable")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("yes")) && (knob.equals("all")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("yes")) && (knob.equals("fail")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (failed_knob.equals("no")) && (isHandle.equals("yes")) && (knob.equals("not_applicable")) && (isKnob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("no")) && (failed_knob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("no")) && (connected_to_failed_knob.equals("yes")) && (connected_to_failed_handle.equals("yes")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("all")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("fail")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("no")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (isKnob.equals("no")) && (located.equals("all")) && (connected_to_failed_knob.equals("yes")) && (failed_knob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (isKnob.equals("no")) && (located.equals("fail")) && (connected_to_failed_knob.equals("no")) && (failed_knob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (isKnob.equals("no")) && (located.equals("fail")) && (connected_to_failed_knob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (connected_to_failed_handle.equals("no")) && (isHandle.equals("yes")) && (isKnob.equals("yes")) ) );
assert( ! ( (failed_handle.equals("yes")) && (knob.equals("not_applicable")) && (connected_to_failed_handle.equals("yes")) ) );

if (knob.equals("all")) {
   doAction = "yes";
 }
 else if (knob.equals("fail")) {
   if (failed_knob.equals("no")) {
     if (connected_to_failed_knob.equals("no")) {
       doAction = "no";
     }
     else if (connected_to_failed_knob.equals("yes")) {
       if (located.equals("all")) {
         doAction = "yes";
       }
       else if (located.equals("fail")) {
         doAction = "no";
       }
     }
   }
   else if (failed_knob.equals("yes")) {
     doAction = "yes";
   }
 }
 else if (knob.equals("not_applicable")) {
   if (located.equals("all")) {
     doAction = "yes";
   }
   else if (located.equals("fail")) {
     if (failed_handle.equals("no")) {
       if (connected_to_failed_handle.equals("no")) {
         if (connected_to_failed_knob.equals("no")) {
           doAction = "no";
         }
         else if (connected_to_failed_knob.equals("yes")) {
           doAction = "yes";
         }
       }
       else if (connected_to_failed_handle.equals("yes")) {
         doAction = "yes";
       }
     }
     else if (failed_handle.equals("yes")) {
       doAction = "yes";
     }
   }
 }
