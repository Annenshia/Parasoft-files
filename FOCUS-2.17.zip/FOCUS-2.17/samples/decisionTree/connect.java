if (failed_handle.equals("no")) {
  if (failed_knob.equals("no")) {
    if (knob.equals("all")) {
      if (isHandle.equals("no")) {
        if (isKnob.equals("no")) {
          assert(false);
        }
        else if (isKnob.equals("yes")) {
          if (located.equals("all")) {
            if (connected_to_failed_handle.equals("no")) {
              doAction = "yes";
            }
            else if (connected_to_failed_handle.equals("yes")) {
              if (connected_to_failed_knob.equals("no")) {
                doAction = "yes";
              }
              else if (connected_to_failed_knob.equals("yes")) {
                assert(false);
              }
            }
          }
          else if (located.equals("fail")) {
            if (connected_to_failed_handle.equals("no")) {
              if (connected_to_failed_knob.equals("no")) {
                assert(false);
              }
              else if (connected_to_failed_knob.equals("yes")) {
                doAction = "yes";
              }
            }
            else if (connected_to_failed_handle.equals("yes")) {
              if (connected_to_failed_knob.equals("no")) {
                doAction = "yes";
              }
              else if (connected_to_failed_knob.equals("yes")) {
                assert(false);
              }
            }
          }
        }
      }
      else if (isHandle.equals("yes")) {
        assert(false);
      }
    }
    else if (knob.equals("fail")) {
      if (isHandle.equals("no")) {
        if (isKnob.equals("no")) {
          assert(false);
        }
        else if (isKnob.equals("yes")) {
          if (connected_to_failed_knob.equals("no")) {
            doAction = "no";
          }
          else if (connected_to_failed_knob.equals("yes")) {
            if (connected_to_failed_handle.equals("no")) {
              if (located.equals("all")) {
                doAction = "yes";
              }
              else if (located.equals("fail")) {
                doAction = "no";
              }
            }
            else if (connected_to_failed_handle.equals("yes")) {
              assert(false);
            }
          }
        }
      }
      else if (isHandle.equals("yes")) {
        assert(false);
      }
    }
    else if (knob.equals("not_applicable")) {
      if (isHandle.equals("no")) {
        assert(false);
      }
      else if (isHandle.equals("yes")) {
        if (isKnob.equals("no")) {
          if (connected_to_failed_handle.equals("no")) {
            if (located.equals("all")) {
              doAction = "yes";
            }
            else if (located.equals("fail")) {
              if (connected_to_failed_knob.equals("no")) {
                doAction = "no";
              }
              else if (connected_to_failed_knob.equals("yes")) {
                doAction = "yes";
              }
            }
          }
          else if (connected_to_failed_handle.equals("yes")) {
            if (connected_to_failed_knob.equals("no")) {
              doAction = "yes";
            }
            else if (connected_to_failed_knob.equals("yes")) {
              assert(false);
            }
          }
        }
        else if (isKnob.equals("yes")) {
          assert(false);
        }
      }
    }
  }
  else if (failed_knob.equals("yes")) {
    if (connected_to_failed_knob.equals("no")) {
      if (connected_to_failed_handle.equals("no")) {
        if (isHandle.equals("no")) {
          if (isKnob.equals("no")) {
            assert(false);
          }
          else if (isKnob.equals("yes")) {
            if (knob.equals("all")) {
              doAction = "yes";
            }
            else if (knob.equals("fail")) {
              doAction = "yes";
            }
            else if (knob.equals("not_applicable")) {
              assert(false);
            }
          }
        }
        else if (isHandle.equals("yes")) {
          if (knob.equals("all")) {
            assert(false);
          }
          else if (knob.equals("fail")) {
            assert(false);
          }
          else if (knob.equals("not_applicable")) {
            if (located.equals("all")) {
              if (isKnob.equals("no")) {
                doAction = "yes";
              }
              else if (isKnob.equals("yes")) {
                assert(false);
              }
            }
            else if (located.equals("fail")) {
              assert(false);
            }
          }
        }
      }
      else if (connected_to_failed_handle.equals("yes")) {
        if (knob.equals("all")) {
          assert(false);
        }
        else if (knob.equals("fail")) {
          assert(false);
        }
        else if (knob.equals("not_applicable")) {
          if (located.equals("all")) {
            if (isHandle.equals("no")) {
              assert(false);
            }
            else if (isHandle.equals("yes")) {
              if (isKnob.equals("no")) {
                doAction = "yes";
              }
              else if (isKnob.equals("yes")) {
                assert(false);
              }
            }
          }
          else if (located.equals("fail")) {
            assert(false);
          }
        }
      }
    }
    else if (connected_to_failed_knob.equals("yes")) {
      assert(false);
    }
  }
}
else if (failed_handle.equals("yes")) {
  if (knob.equals("all")) {
    assert(false);
  }
  else if (knob.equals("fail")) {
    assert(false);
  }
  else if (knob.equals("not_applicable")) {
    if (connected_to_failed_handle.equals("no")) {
      if (isHandle.equals("no")) {
        assert(false);
      }
      else if (isHandle.equals("yes")) {
        if (isKnob.equals("no")) {
          if (located.equals("all")) {
            if (connected_to_failed_knob.equals("no")) {
              doAction = "yes";
            }
            else if (connected_to_failed_knob.equals("yes")) {
              if (failed_knob.equals("no")) {
                doAction = "yes";
              }
              else if (failed_knob.equals("yes")) {
                assert(false);
              }
            }
          }
          else if (located.equals("fail")) {
            if (connected_to_failed_knob.equals("no")) {
              if (failed_knob.equals("no")) {
                doAction = "yes";
              }
              else if (failed_knob.equals("yes")) {
                assert(false);
              }
            }
            else if (connected_to_failed_knob.equals("yes")) {
              assert(false);
            }
          }
        }
        else if (isKnob.equals("yes")) {
          assert(false);
        }
      }
    }
    else if (connected_to_failed_handle.equals("yes")) {
      assert(false);
    }
  }
}
