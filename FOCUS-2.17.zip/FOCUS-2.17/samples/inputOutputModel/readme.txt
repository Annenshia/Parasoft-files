The zoo model is an example for an input/output model. Look at the 
restrictions, then generate an input/output report. The input and output are
many-to-many, so the first two tabs are very populated. There is no unused 
value. There are illegal output combinations, all explicit (blue), and illegal
input combinations, some red and some blue. The following two variations are 
interesting:
1. Add restriction (not allowed) annualCost >= 1000. You can see that it appears 
 as unused value, and also area=acre becomes unused. Many more 'red' illegal
 input combinations appear.
2. Remove the annualCost attribute and all restrictions containing it. Now the
 output is a function of the input, and the first tab becomes empty.